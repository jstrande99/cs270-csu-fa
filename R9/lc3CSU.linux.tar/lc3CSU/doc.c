
/** @mainpage LC3 Tools at Colorado State University 
 *  \htmlinclude "LC3CSU.html"
 */

// dummy C file for doxygen

